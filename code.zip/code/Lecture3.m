clc
clear all
close all

% im = imread('sampleimage4.tif');
% im_eq = histeq(im);
% imshow(im_eq);
% subplot(1,2,1)
% imshow((im))
% subplot(1,2,2)
% imshow(mat2gray(im_eq))

im = imread('flower.jpg'); % 108073.png flower.jpg
% im = imresize(im,.25);
im = rgb2gray(im);
im = double(im);
out = zeros(size(im));
filter = [1 1 1;1 -8 1;1 1 1];
% [1 1 1;1 1 1;1 1 1];
% [1 1 1;1 -8 1;1 1 1];


% out = conv2(im,filter);

for row = 2 : size(im,1)-1
    for col = 2 : size(im,2)-1
        
        temp1 = row - 1;
        temp2 = col - 1;
        sub_block = im(temp1:temp1 + 2,temp2:temp2+2);
        
        %         sub_block = im(temp1:temp1 + 2,temp2:temp2+2,:);
        %         r = sum(sum(sub_block(:,:,1) .* filter));
        %         g = sum(sum(sub_block(:,:,2) .* filter));
        %         b = sum(sum(sub_block(:,:,3) .* filter));
        %         out(row,col,1) = r;
        %         out(row,col,2) = g;
        %         out(row,col,3) = b;
        
        val = sum(sum(sub_block .* filter));
        % val = sum(sum(sub_block .* filter));
        out(row,col) = val;
        
    end
end

% out2 = im + im - out;
out2 =  im - out;

subplot(1,2,1)
imshow(mat2gray(im))
subplot(1,2,2)
imshow(mat2gray(out2))