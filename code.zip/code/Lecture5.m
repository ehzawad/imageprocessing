clc
clear all
close all


footBall=imread('footBall_orig.jpg');
footBall=rgb2gray(footBall);

% footBall=zeros(30,30);
% footBall(5:24,13:17)=1;

PQ = paddedsize(size(footBall));
F=fft2(double(footBall),PQ(1),PQ(2));

im = ifft2((F));
im2=im(1:size(footBall,1), 1:size(footBall,2));

% Display the Fourier Spectrum
Fc=fftshift(F); 
S2=log(1+abs(Fc));
S3=log(1+angle(Fc));

% reconstract with real part
F_real = real(F);
im = ifft2(F_real);
im_real=im(1:size(footBall,1), 1:size(footBall,2));

% reconstract with imaginary part
F_imag = imag(F);
im = ifft2(F_imag);
im_imag=im(1:size(footBall,1), 1:size(footBall,2));


subplot(2,2,1);
imshow(footBall,[])

subplot(2,2,2);
imshow(im2,[])

subplot(2,2,3);
imshow(S2 .* S2,[]) % Fourier Spectrum
% imshow(S3,[]) % phase angle

subplot(2,2,4);
imshow(im_imag,[]) % im_real im_imag

% footBall=imread('footBall_orig.jpg');
% footBall=footBall(:,:,1); % Grab only the Red component to fake gray scaling
% imshow(footBall)
% PQ = paddedsize(size(footBall));
% D0 = 0.05*PQ(1);
% H = lpfilter('gaussian', PQ(1), PQ(2), D0); % Calculate the LPF
% F=fft2(double(footBall),size(H,1),size(H,2)); % Calculate the discrete Fourier transform of the image
% LPF_football=real(ifft2(H.*F)); % multiply the Fourier spectrum by the LPF and apply the inverse, discrete Fourier transform
% LPF_football=LPF_football(1:size(footBall,1), 1:size(footBall,2)); % Resize the image to undo padding
% % figure, imshow(LPF_football, [])
% % Display the Fourier Spectrum
% Fc=fftshift(F); % move the origin of the transform to the center of the frequency rectangle
% S2=log(1+abs(Fc)); % use abs to compute the magnitude (handling imaginary) and use log to brighten display
% % figure, imshow(S2,[])


% footBall=imread('football.jpg');
% footBall=footBall(:,:,1); % Grab only the Red component to fake gray scaling
% imshow(footBall)
% PQ = paddedsize(size(footBall));
% D0 = 0.05*PQ(1);
% H = hpfilter('gaussian', PQ(1), PQ(2), D0); % Calculate the HPF
% F=fft2(double(footBall),size(H,1),size(H,2)); % Calculate the discrete Fourier transform of the image
% HPF_football=real(ifft2(H.*F)); % multiply the Fourier spectrum by the LPF and apply the inverse, discrete Fourier transform
% HPF_football=LPF_football(1:size(footBall,1), 1:size(footBall,2)); % Resize the image to undo padding
% figure, imshow(HPF_football, [])
% % Display the Fourier Spectrum
% Fc=fftshift(F); % move the origin of the transform to the center of the frequency rectangle
% S2=log(1+abs(Fc)); % use abs to compute the magnitude (handling imaginary) and use log to brighten display
% figure, imshow(S2,[])