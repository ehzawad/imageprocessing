clc
clear all
close all


footBall=imread('footBall_orig.jpg');
footBall=rgb2gray(footBall);

% footBall=zeros(30,30);
% footBall(5:24,13:17)=1;

[rows, columns, numberOfColorChannels] = size(footBall);



PQ = paddedsize(size(footBall));

% n = 9;
% hz = (1/(n*n))*ones(n,n);

% sigma = 3; n = 9;
% hz = fspecial('gaussian',[9,9],sigma);

hz=fspecial('sobel'); hz = hz';

HZ=fftshift(fft2(double(hz), PQ(1), PQ(2)));


% dist = distmatrix(PQ(1), PQ(2));
% dist = fftshift(dist);
% % HZ = double(dist <=50); % ideal low pass
% HZ = double(dist > 50); % ideal high pass

% Define frequency domain filter the same size as the image.
% HZ = fspecial('gaussian', [PQ(1), PQ(2)], 0.04*PQ(1)); % Keep the low frequencies.  Decrease the 0.2 to make it exclude more high frequencies.


% Fourier transform the noisy image.
freqDomainImage = fftshift(fft2(footBall, PQ(1), PQ(2)));

% Now do filtering in the frequency domain
filteredFreqDomain = freqDomainImage .* HZ;

% subplot(1,2,1);
% imshow(log(fft2(footBall, PQ(1), PQ(2))),[])
% subplot(1,2,2)
% imshow(log(fftshift(fft2(footBall, PQ(1), PQ(2)))),[])

% Now transform back to spatial domain:
spatialImage = abs(ifft2(ifftshift(filteredFreqDomain),PQ(1), PQ(2)));


% Display results:
subplot(2, 2, 1); imshow(footBall, []);
% subplot(2, 2, 1); imshow(mat2gray(out), []);
subplot(2, 2, 2); imshow(log(abs(freqDomainImage)), []); 
subplot(2, 2, 3); imshow(log(abs(filteredFreqDomain)), []); 
subplot(2, 2, 4); imshow(spatialImage(1:size(footBall,1), 1:size(footBall,2)), []);




