clc
clear all
close all

%% Image read write
im = imread('flower.jpg');
imgray = rgb2gray(im); %  0.299 * R + 0.587 * G + 0.114 * B

% imshow(imgray);
% imwrite(imgray, 'flower_gray.jpg');

im_tras = imgray;

for i = 1 : size(imgray,1)
    for j = 1 : size(imgray,2)
        im_tras(i,j) = 255 - imgray(i,j);
    end
end

subplot(1,2,1)
imshow(imgray)

subplot(1,2,2)
imshow(mat2gray(im_tras))